

const functions = require('firebase-functions');

// Example: Firebase Cloud Function triggered by an HTTP request
exports.exampleFunction = functions.https.onRequest((req, res) => {
  res.send('Hello from Firebase Cloud Function!');
});

// Example: Firebase Cloud Function triggered by a Firestore event
exports.firestoreFunction = functions.firestore
  .document('quotes/{quoteId}')
  .onCreate((snapshot, context) => {
    const data = snapshot.data();
    console.log('New quote added:', data);
    return null;
});
