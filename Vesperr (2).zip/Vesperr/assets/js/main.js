/**
* Template Name: Vesperr
* Updated: Sep 18 2023 with Bootstrap v5.3.2
* Template URL: https://bootstrapmade.com/vesperr-free-bootstrap-template/
* Author: BootstrapMade.com
* License: https://bootstrapmade.com/license/
*/



// app.js


// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
// Import necessary Firebase and Stripe modules
const functions = require('firebase-functions');
const admin = require('firebase-admin');
const stripe = require('stripe')('pk_test_51OVGz7A4i0UX7TF4lYGXWfzn7Cjp4fcB2hNxhCvjbfpu6moazsS6z00xDSfdztyBtQrO2PT0mIeVF9LyTLRto2Tx001JbaP70u');

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
var database = firebase.database();

// Firebase configuration
var firebaseConfig = {
  apiKey: "your_api_key",
  authDomain: "your_auth_domain",
  projectId: "your_project_id",
  storageBucket: "your_storage_bucket",
  messagingSenderId: "your_messaging_sender_id",
  appId: "your_app_id",
  measurementId: "your_measurement_id"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);



// Initialize Firebase Admin
admin.initializeApp();

// Example usage
fetchDataAndProcess();

/**(function() {
  "use strict";

  
  
   * Navbar links active state on scroll
   
  let navbarlinks = select('#navbar .scrollto', true)
  const navbarlinksActive = () => {
    let position = window.scrollY + 200
    navbarlinks.forEach(navbarlink => {
      if (!navbarlink.hash) return
      let section = select(navbarlink.hash)
      if (!section) return
      if (position >= section.offsetTop && position <= (section.offsetTop + section.offsetHeight)) {
        navbarlink.classList.add('active')
      } else {
        navbarlink.classList.remove('active')
      }
    })
  }
  window.addEventListener('load', navbarlinksActive)
  onscroll(document, navbarlinksActive)

  /**
   * Scrolls to an element with header offset
   
  const scrollto = (el) => {
    let header = select('#header')
    let offset = header.offsetHeight

    if (!header.classList.contains('header-scrolled')) {
      offset -= 20
    }

    let elementPos = select(el).offsetTop
    window.scrollTo({
      top: elementPos - offset,
      behavior: 'smooth'
    })
  }

  
  /**
   * Back to top button
   
  let backtotop = select('.back-to-top')
  if (backtotop) {
    const toggleBacktotop = () => {
      if (window.scrollY > 100) {
        backtotop.classList.add('active')
      } else {
        backtotop.classList.remove('active')
      }
    }
    window.addEventListener('load', toggleBacktotop)
    onscroll(document, toggleBacktotop)
  }*/

  /**
   * Mobile nav toggle
   
  on('click', '.mobile-nav-toggle', function(e) {
    select('#navbar').classList.toggle('navbar-mobile')
    this.classList.toggle('bi-list')
    this.classList.toggle('bi-x')
  })*/

  /**
   * Mobile nav dropdowns activate
   
  on('click', '.navbar .dropdown > a', function(e) {
    if (select('#navbar').classList.contains('navbar-mobile')) {
      e.preventDefault()
      this.nextElementSibling.classList.toggle('dropdown-active')
    }
  }, true)*/

  /**
   * Scrool with ofset on links with a class name .scrollto
  
  on('click', '.scrollto', function(e) {
    if (select(this.hash)) {
      e.preventDefault()

      let navbar = select('#navbar')
      if (navbar.classList.contains('navbar-mobile')) {
        navbar.classList.remove('navbar-mobile')
        let navbarToggle = select('.mobile-nav-toggle')
        navbarToggle.classList.toggle('bi-list')
        navbarToggle.classList.toggle('bi-x')
      }
      scrollto(this.hash)
    }
  }, true) 

  /**
   * Scroll with ofset on page load with hash links in the url
   
  window.addEventListener('load', () => {
    if (window.location.hash) {
      if (select(window.location.hash)) {
        scrollto(window.location.hash)
      }
    }
  });

  

  /**
   * Animation on scroll
   
  window.addEventListener('load', () => {
    AOS.init({
      duration: 1000,
      easing: 'ease-in-out',
      once: true,
      mirror: false
    })
  });

  /**
   * Initiate Pure Counter 
   
  new PureCounter();

})()*/
  
// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-analytics.js";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries
import { getDatabase, ref, push } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-database.js";





// Firebase Cloud Function to create a Payment Intent
exports.createPaymentIntent = functions.https.onRequest(async (req, res) => {
  try {
    // Extract payment details from the request
    const { amount, currency, customerId } = req.body;

    // Create a Payment Intent on Stripe
    const paymentIntent = await stripe.paymentIntents.create({
      amount,
      currency,
      customer: customerId,
    });

    // Respond with the client secret
    res.json({ clientSecret: paymentIntent.client_secret });
  } catch (error) {
    console.error('Error creating Payment Intent:', error.message);
    res.status(500).send('Error creating Payment Intent');
  }
});

// Your existing code...

function checkRegistration() {
  const registrationNumber = document.getElementById('registration').value;
  const apiUrl = 'https://api.vehicle-search.co.uk/#/';

  fetch(apiUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ registration: registrationNumber }),
  })
  .then(response => {
    if (!response.ok) {
      throw new Error(`Error: ${response.status} - ${response.statusText}`);
    }
    return response.json();
  })
  .then(data => {
    if (data.valid) {
      displayQuotation(data);
      displayCarDetails(data.carDetails);
      displayPaymentForm(data.amount);
    } else {
      displayError("Invalid Registration Number. Please try again.");
    }
  })
  .catch(error => {
    console.error('Error checking registration:', error.message);
    displayError(error.message);
  });
}

function displayCarDetails(carDetails) {
  const resultContainer = document.getElementById('quotationResult');

  // Display the car details
  resultContainer.innerHTML += `
    <h2>Car Details</h2>
    <p><strong>Make:</strong> ${carDetails.make}</p>
    <p><strong>Model:</strong> ${carDetails.model}</p>
    <p><strong>Color:</strong> ${carDetails.color}</p>
    <p><strong>Chassis Number:</strong> ${carDetails.chassisNumber}</p>
  `;
}

// Your existing functions...


function displayQuotation(quotationData) {
  const resultContainer = document.getElementById('quotationResult');
  
  // Display the quotation details
  resultContainer.innerHTML = `
      <h2>Quotation Details</h2>
      <p><strong>Registration Number:</strong> ${quotationData.registration}</p>
      <p><strong>Insurance Amount:</strong> ${quotationData.amount}</p>
      <!-- Add more details as needed -->
  `;
}


// Import the Stripe.js library
import { Stripe } from 'stripe-js'; // Include the correct path to the Stripe library

// Your existing code...

// Initialize Stripe with your publishable key

function processPayment() {
  const fullName = document.getElementById('fullName').value;
  const email = document.getElementById('email').value;
  const paymentAmount = document.getElementById('paymentAmount').value;

  // Use Stripe.js to create a payment token
  stripe.createToken({
    name: fullName,
    address_email: email,
  }).then(result => {
    if (result.error) {
      // Handle errors (e.g., card validation failure)
      displayError(result.error.message);
    } else {
      // Send the token to your server for further processing
      const paymentToken = result.token.id;
      storePaymentDetails({ fullName, email, paymentAmount, paymentToken });
    }
  });
}

// Your existing functions...

function storePaymentDetails(customerDetails) {
  const apiUrl = 'https://your-backend-api.com/store-payment-details';

  fetch(apiUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(customerDetails),
  })
  .then(response => {
    if (!response.ok) {
      throw new Error(`Error: ${response.status} - ${response.statusText}`);
    }
    return response.json();
  })
  .then(data => {
    console.log('Payment details stored successfully:', data);
  })
  .catch(error => {
    console.error('Error storing payment details:', error.message);
  });
}

